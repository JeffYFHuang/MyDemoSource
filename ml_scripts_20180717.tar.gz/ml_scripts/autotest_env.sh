#!/usr/bin/env bash

#env - `cat /home/ubuntu/ml_scripts/my_env.sh` /bin/sh

bdate=$(date --date="yesterday" +"%Y-%m-%d")
echo "today is "$bdate
days=1

echo "starting ML script"

#bdate=$(date --date="today" +"%Y-%m-%d")
#bdate=$1
#days=$2

#ip="10.10.10.15" #flume server ip

#. ./autosend.sh $bdate $days $ip
./autocal.sh $bdate $days
