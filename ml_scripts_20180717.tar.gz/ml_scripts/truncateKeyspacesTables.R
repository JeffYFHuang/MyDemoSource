#! /usr/bin/env Rscript
source("src/cassandraFuncs.R")

school.id <- getKeyspaces()
#truncateKeyspacesTables(school.id)
#CreateSchoolsInfo(school.id)

