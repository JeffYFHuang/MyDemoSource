#.libPaths("/usr/local/spark/spark-2.1.0-bin-hadoop2.7/R/lib")
library(RCurl)

library(rjson)
library(compiler)
#source("genActData_v2.Rc")
loadcmp("genActData_v2.Rc")

send_phydummy <- function (sid, data, time, addr="10.10.10.15", port=44448) {
    data$year=format(as.POSIXct(time, origin="1970-01-01", tz="GMT"), paste("%Y", sep=""))
    data$month=format(as.POSIXct(time, origin="1970-01-01", tz="GMT"), paste("%m", sep=""))
    data$date=format(as.POSIXct(time, origin="1970-01-01", tz="GMT"), paste("%d", sep=""))
    data$hour_range=format(as.POSIXct(time, origin="1970-01-01", tz="GMT"), paste("%H", sep=""))
    #data$year=as.character(year(as.POSIXct(time, origin="1970-01-01", tz="GMT")))
    #data$month=as.character(month(as.POSIXct(time, origin="1970-01-01", tz="GMT")))
    #data$date=as.character(day(as.POSIXct(time, origin="1970-01-01", tz="GMT")))
    #data$hour_range=as.character(hour(as.POSIXct(time, origin="1970-01-01", tz="GMT")))
    cat(format(as.POSIXct(time, origin="1970-01-01", tz="GMT"), "%Y-%m-%d %H"), "\n")
    payload = toJSON(data)
#    cat(payload, "\n")
#    headers = format(as.POSIXct(time, origin="1970-01-01", tz="GMT"), paste('"headers":{"m_year":"%Y","m_month":"%m","m_day":"%d", "m_hour":"%H", "m_school": "', sid, '"}', sep=""))

#    http_content = paste('[{', headers, ',"body":', "'", payload, "'", '}]', sep="")
    http_content = payload
    httpheader <- c(Accept="application/json; charset=UTF-8", "Content-Type"="application/json")
    result = postForm(paste("http://", addr, ":", port, sep=""), .opts=list(httpheader=httpheader, postfields=http_content))
    show (result)
}

args=(commandArgs(TRUE))
bdate = NULL
ip = NULL
port = NULL
hours = NULL
args=(commandArgs(TRUE))

if (length(args) != 0){
  for (i in 1:length(args)){
     eval(parse(text=args[[i]]))
  }
}

execution = "Exe. Rscript send_phydummy.R \"ip='10.10.10.15'\" bdate=\"'2017-05-01'\" port=44448 hours=12";
#execution = "Exe. Rscript send_phydummy.R ip=10.10.10.7 bdate=\"'2017-05-01'\" port=44448 range='1:50' hours=12";
if (is.null(ip))
   stop(paste("please provide flume server address!", execution))
if (is.null(port))
   stop(paste("please provide port of flume service!", execution))
if (is.null(bdate))
   stop(paste("please provide date!", execution))
if (is.null(hours))
   stop(paste("please provide the number of hours!", execution))

flumeserver = ip

devices.info <- read.csv("devices.csv", header=T)
#print(devices.info$device_id)
#for (h in 1:4) {
#    time = now()
#    beginDate <- floor_date(as.Date(date(now())) - 1, "months")
    datetime = as.POSIXlt(paste(bdate, 8), format="%Y-%m-%d %H", tz="GMT")
    print(datetime)
#    time = time + (h - 1) * hours*60*60

#set.seed(as.integer(as.numeric(time)))
i <- 1
for (sid in unique(devices.info$school_id)) {
    #print(devices.info$uuid[which(devices.info$school_id == sid)])
    #seeds <- uuid.seeds[which(devices.info$school_id == sid)]
    for (uid in devices.info$uuid[which(devices.info$school_id == sid)]) {
       config_id <- devices.info$device_id[which(devices.info$uuid == uid)]
       cat(i, sid, " ", uid, " ", config_id, "\n")
       set.seed(as.integer(as.numeric(datetime)) + as.integer(config_id))
#       cat("seed", as.integer(as.numeric(datetime)) + as.integer(config_id), "\n")
       data <- genActDataV2(uid, datetime, hours*60*60, win = 6*60*60)
#       print(length(data))
       for (x in data) {
           x$sid = paste("elm", sid, sep="")
           send_phydummy (x$sid, x, x$data[[1]]$timestamp, addr = flumeserver)
       }
       i <- i + 1
    }
}

#}
