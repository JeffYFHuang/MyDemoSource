#!/usr/bin/env bash
PATH=$PATH:/usr/sbin:/usr/bin:/sbin:/bin:/opt/hadoop/bin:/opt/hadoop/sbin:/usr/local/flume/apache-flume-1.7.0-bin/bin
bdate=$(date --date="yesterday" +"%Y-%m-%d")
days=1

echo "starting ML script"

#bdate=$(date --date="today" +"%Y-%m-%d")
#bdate=$1
#days=$2

ip="10.10.10.15" #flume server ip

#. ./autosend.sh $bdate $days $ip
./autocal.sh $bdate $days


