#!/bin/bash

bdate=$1
days=$2
ip=$3

. ./send_phydummy_elm32.sh $bdate $days $ip

