
HADOOP_CMD=/usr/local/hadoop/bin/hadoop
SHELL=/bin/bash
TERM=xterm-256color
HADOOP_HOME=/usr/local/hadoop
YARN_PID_DIR=/var/run/hadoop
HADOOP_PID_DIR=/var/run/hadoop
HADOOP_MAPRED_PID_DIR=/var/run/hadoop
USER=ubuntu
LS_COLORS=rs=0:di=01;34:ln=01;36:mh=00:pi=40;33:so=01;35:do=01;35:bd=40;33;01:cd=40;33;01:or=40;31;01:su=37;41:sg=30;43:ca=30;41:tw=$
SUDO_USER=ubuntu
SUDO_UID=1000
USERNAME=ubuntu
MAIL=/var/mail/ubuntu
PATH=/usr/lib/jvm/java-7-openjdk-amd64/bin:/usr/lib/jvm/java-7-openjdk-amd64/jre/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/b$:/usr/local/hadoop/bin
HADOOP_HDFS_HOME=/usr/local/hadoop
HADOOP_COMMON_HOME=/usr/local/hadoop
PWD=/home/ubuntu/ml_script
HADOOP_YARN_HOME=/usr/local/hadoop
JAVA_HOME=/usr/lib/jvm/java-7-openjdk-amd64/jre
HADOOP_CONF_DIR=/usr/local/hadoop/etc/hadoop
LANG=en_US.UTF-8
HADOOP_STREAMING=/usr/local/hadoop/share/hadoop/tools/lib/hadoop-streaming-2.6.0.jar
SHLVL=1
SUDO_COMMAND=/bin/bash
HOME=/home/ubuntu
HADOOP_MAPRED_HOME=/usr/local/hadoop
LOGNAME=ubuntu
LESSOPEN=| /usr/bin/lesspipe %s
SUDO_GID=1000
LESSCLOSE=/usr/bin/lesspipe %s %s
_=/usr/bin/env
OLDPWD=/home/ubuntu/ml_scripts/logs



