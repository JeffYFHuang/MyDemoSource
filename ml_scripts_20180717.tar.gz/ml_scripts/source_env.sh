#!/bin/bash

#import env variables
env - `cat /root/forDemo/my_env.sh` /bin/sh


