#!/usr/bin/env python

from cassandra.auth import PlainTextAuthProvider
from cassandra.cluster import Cluster
import json


#Auth = PlainTextAuthProvider(username='cassan_root', password='Cassandra@007')
cluster = Cluster(['172.18.0.7', '172.18.0.13'], auth_provider=Auth)
session = cluster.connect();
session.default_timeout = 3600

#def selectAll(keyspace, tblname):
#        session.set_keyspace(keyspace)
#       rows = session.execute('SELECT * FROM ' + tblname)
#        return list(rows)

def setkeyspace(keyspace):
        return session.set_keyspace(keyspace)

def cqlexec(cqlcmd):
        result = session.execute(cqlcmd)
        return list(result)

def cqlexecwithkeyspace(keyspace, cqlcmd):
        session.set_keyspace(keyspace)
        result = session.execute(cqlcmd)
        return list(result)

