#! /usr/bin/env Rscript

# reducer.R - Wordcount program in R
# script for Reducer (R-Hadoop integration)
require(rjson)
require(rPython)

GetPredictedMaxHR <- function (age) {
   return(220 - age)
}

trimWhiteSpace <- function(line) gsub("(^ +)|( +$)", "", line)

RoundValues <- function (values) {
    fields <- c("situation", "ts", "min", "max", "count", "duration", "hrmcount", "activeindex", "met", "type", "count", "distance", "cal", "status", "duration")

    values[which(names(values) != "uuid")] <- as.numeric(values[which(names(values) != "uuid")])
    values[names(values) %in% fields] <- as.integer(round(as.numeric(values[names(values) %in% fields])))
    return(values[!is.na(values)])
}

getInsertCqlCmd <- function(tblname, values) {
    if (length(values) <= 0) return(NULL)

    values <- RoundValues(values)
    #print(paste("values : ", values))
    cqlcmd <- paste("INSERT INTO", tblname)
    colnames <- names(values)
    colnames[which(colnames=="datehour")] <- "ts"
    cqlcmd <- paste(cqlcmd, "(", paste(colnames[which(colnames!='uuid')], collapse=", "), ",", colnames[which(colnames=='uuid')], ")")
    cqlcmd <- paste(cqlcmd, " VALUES (", paste(values[which(colnames != "uuid")], collapse=", "))
    cqlcmd <- paste(cqlcmd, ", '", values$uuid, "')", sep="")
    #print(paste("getInsertCqlCmd : tblname ", tblname))
    return(cqlcmd)
}

#env <- new.env(hash = TRUE)
#python.load("src/funcs.py", get.exception = T)

SetupPyCasDriver <- function () {
    python.exec("from cassandra.cluster import Cluster")
    python.exec("from cassandra.auth import PlainTextAuthProvider")
    python.exec("import json")
    python.exec("Auth = PlainTextAuthProvider(username='cassan_root', password='Cassandra@007')")
    python.exec("cluster = Cluster(['10.10.10.31', '10.10.10.25'], control_connection_timeout=None, auth_provider=Auth)")
    python.exec("session = cluster.connect();")
    python.exec("session.default_timeout = 3600")
    python.exec("def setkeyspace(keyspace):return session.set_keyspace(keyspace)")
    python.exec("def cqlexec(cqlcmd):result = session.execute(cqlcmd);return list(result)")
}
#print(paste("Calling","SetupPyCasDriver"))
SetupPyCasDriver()

con <- file("stdin", open = "r")
while (length(line <- readLines(con, n = 1, warn = FALSE)) > 0) {
    data <- fromJSON(line)

    keyspace <- data$keyspace
    for (n in names(data)[-c(1, 2)]) {
        for (d in data[[n]]) {
           d$uuid <- data$uuid
           # for hour table
           cat(keyspace, "\n")
           cqlcmd <- getInsertCqlCmd(paste(keyspace, ".", n, "_hour", sep=""), d)
           cat(cqlcmd, "\n")
           python.call("cqlexec", cqlcmd)
        }
    }
    cat(line, "\n")
}
#print(paste("procesPhyReducer", "Closing", "Connection"))
close(con)

