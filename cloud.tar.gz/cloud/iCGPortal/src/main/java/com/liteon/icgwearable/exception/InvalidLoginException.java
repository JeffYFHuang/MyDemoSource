package com.liteon.icgwearable.exception;

public class InvalidLoginException {

}
