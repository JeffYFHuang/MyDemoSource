package com.liteon.icgwearable.model;

public interface Model {

}
