package com.liteon.icgwearable.model;

public class RewardsCategoryModel {
	
	private Integer school_id;
	private String category_name;
	private String category_icon_url;
	
	
	public int getSchool_id() {
		return school_id;
	}
	public void setSchool_id(int school_id) {
		this.school_id = school_id;
	}
	public String getCategory_name() {
		return category_name;
	}
	public void setCategory_name(String category_name) {
		this.category_name = category_name;
	}
	public String getCategory_icon_url() {
		return category_icon_url;
	}
	public void setCategory_icon_url(String category_icon_url) {
		this.category_icon_url = category_icon_url;
	}
	

}
