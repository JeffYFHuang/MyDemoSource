package com.liteon.icgwearable.model;

import java.util.Date;

public class LatestAnnoncementModel {
	
	private Date latestDate;
	private String name; 
	
	public Date getLatestDate() {
		return latestDate;
	}
	public void setLatestDate(Date latestDate) {
		this.latestDate = latestDate;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	

}
