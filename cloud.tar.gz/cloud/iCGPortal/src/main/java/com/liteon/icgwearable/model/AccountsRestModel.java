package com.liteon.icgwearable.model;

public class AccountsRestModel {

	private Integer accountId;
	private String accountType;

	
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
}
