package com.liteon.icgwearable.service;

public interface SystemConfigurationService {
	public Integer[] findSystemConfigurationParameters(int id);
}
