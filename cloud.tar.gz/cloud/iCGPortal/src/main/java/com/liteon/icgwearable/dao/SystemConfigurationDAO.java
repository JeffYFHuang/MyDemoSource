package com.liteon.icgwearable.dao;

public interface SystemConfigurationDAO {

	public Integer[] findSystemConfigurationParameters(int id);
}
