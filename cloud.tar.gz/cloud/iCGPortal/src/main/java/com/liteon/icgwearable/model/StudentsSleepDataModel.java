package com.liteon.icgwearable.model;

public class StudentsSleepDataModel {

	
	private int studentId;
	private String allow_sleep_data;
	
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public String getAllow_sleep_data() {
		return allow_sleep_data;
	}
	public void setAllow_sleep_data(String allow_sleep_data) {
		this.allow_sleep_data = allow_sleep_data;
	}
	
}
