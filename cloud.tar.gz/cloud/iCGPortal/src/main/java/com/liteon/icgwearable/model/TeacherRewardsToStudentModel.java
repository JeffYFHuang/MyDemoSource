package com.liteon.icgwearable.model;

public class TeacherRewardsToStudentModel {
	
	private Integer student_id;
	private Integer received_count;
	
	public Integer getStudent_id() {
		return student_id;
	}
	public void setStudent_id(Integer student_id) {
		this.student_id = student_id;
	}
	public Integer getReceived_count() {
		return received_count;
	}
	public void setReceived_count(Integer received_count) {
		this.received_count = received_count;
	}
}
