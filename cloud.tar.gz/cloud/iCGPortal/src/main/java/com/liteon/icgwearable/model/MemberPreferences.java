package com.liteon.icgwearable.model;

public class MemberPreferences {
	
	private String  alertId;
	
	public String getAlertId() {
		return alertId;
	}
	public void setAlertId(String alertId) {
		this.alertId = alertId;
	}
	public String getAlertValue() {
		return alertValue;
	}
	public void setAlertValue(String alertValue) {
		this.alertValue = alertValue;
	}
	private String alertValue;
	

}
