package com.liteon.icgwearable.transform;

public class AccountsTransform {

	private Integer accountId;

	public AccountsTransform() {
	}

	public Integer getAccountId() {
		return accountId;
	}

	public void setAccountId(Integer accountId) {
		this.accountId = accountId;
	}

}
