package com.liteon.icgwearable.model;

public class DeviceEliminateModel implements Model {

	private Integer queueid;

	public Integer getQueueid() {
		return queueid;
	}
	public void setQueueid(Integer queueid) {
		this.queueid = queueid;
	}
	
}
