package com.liteon.icgwearable.model;

public class TokenUpdateModel {
	private String appToken;
	public String getAppToken() {
		return appToken;
	}
	public void setAppToken(String appToken) {
		this.appToken = appToken;
	}
	
	private String appType;
	public String getAppType() {
		return appType;
	}
	public void setAppType(String appType) {
		this.appType = appType;
	}
	

}
