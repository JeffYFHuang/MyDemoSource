function showSort(){
	$('#sortModal').modal('show');
}
	
