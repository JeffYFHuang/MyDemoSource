
INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511766049, 7);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511679648, 14);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511593248, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511506848, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511420448, 14);


INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('5d7fae93-96fd-4c4249-90969d-4073925ae1b6', 1511766049, 13);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('5d7fae93-96fd-4c4249-90969d-4073925ae1b6', 1511679648, 2);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('5d7fae93-96fd-4c4249-90969d-4073925ae1b6', 1511593248, 7);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('5d7fae93-96fd-4c4249-90969d-4073925ae1b6', 1511506848, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('5d7fae93-96fd-4c4249-90969d-4073925ae1b6', 1511420448, 14);



INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('63026db6-cf0f-4fb2-aefd-f297e451a346', 1511766049, 7);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('63026db6-cf0f-4fb2-aefd-f297e451a346', 1511679648, 14);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('63026db6-cf0f-4fb2-aefd-f297e451a346', 1511593248, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('63026db6-cf0f-4fb2-aefd-f297e451a346', 1511506848, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('63026db6-cf0f-4fb2-aefd-f297e451a346', 1511420448, 14);



INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511679648, 2);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511593248, 7);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511761722, 14);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511506848, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511420448, 14);


INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511679648, 2);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511593248, 7);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511761722, 14);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511506848, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511420448, 14);



INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511679648, 2);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511593248, 7);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511761722, 14);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511506848, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511420448, 14);



INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511679648, 2);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511593248, 7);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511761722, 14);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511506848, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511420448, 14);



INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511679648, 2);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511593248, 7);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511761722, 14);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511506848, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511420448, 14);


INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511679648, 2);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511593248, 7);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511761722, 14);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511506848, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511420448, 14);



INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511679648, 2);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511593248, 7);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511761722, 14);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511506848, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511420448, 14);





INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511679648, 2);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511593248, 7);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511761722, 14);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511506848, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511420448, 14);





INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511679648, 2);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511593248, 7);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511761722, 14);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511506848, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511420448, 14);



INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511679648, 2);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511593248, 7);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511761722, 14);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511506848, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511420448, 14);



INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511679648, 2);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511593248, 7);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511761722, 14);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511506848, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511420448, 14);



INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511679648, 2);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511593248, 7);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511761722, 14);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511506848, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511420448, 14);




INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511679648, 2);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511593248, 7);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511761722, 14);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511506848, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511420448, 14);




INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511679648, 2);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511593248, 7);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511761722, 14);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511506848, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511420448, 14);



INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511679648, 2);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511593248, 7);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511761722, 14);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511506848, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511420448, 14);





INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511679648, 2);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511593248, 7);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511761722, 14);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511506848, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511420448, 14);



INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511679648, 2);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511593248, 7);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511761722, 14);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511506848, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511420448, 14);



INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511679648, 2);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511593248, 7);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511761722, 14);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511506848, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511420448, 14);



INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511679648, 2);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511593248, 7);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511761722, 14);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511506848, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511420448, 14);


INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511679648, 2);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511593248, 7);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511761722, 14);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511506848, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511420448, 14);



INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511679648, 2);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511593248, 7);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511761722, 14);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511506848, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511420448, 14);



INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511679648, 2);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511593248, 7);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511761722, 14);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511506848, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511420448, 14);



INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511679648, 2);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511593248, 7);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511761722, 14);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511506848, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511420448, 14);



INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511679648, 2);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511593248, 7);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511761722, 14);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511506848, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511420448, 14);



INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511679648, 2);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511593248, 7);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511761722, 14);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511506848, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511420448, 14);


INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2e', 1511679648, 2);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2e', 1511593248, 7);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2e', 1511761722, 14);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2e', 1511506848, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2e', 1511420448, 14);



INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511679648, 2);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511593248, 7);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511761722, 14);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511506848, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511420448, 14);


INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511679648, 2);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511593248, 7);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511761722, 14);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511506848, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511420448, 14);




INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511679648, 2);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511593248, 7);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511761722, 14);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511506848, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511420448, 14);




INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511679648, 2);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511593248, 7);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511761722, 14);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511506848, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511420448, 14);



INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511679648, 2);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511593248, 7);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511761722, 14);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511506848, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511420448, 14);



INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511679648, 2);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511593248, 7);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511761722, 14);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511506848, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511420448, 14);



INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511679648, 2);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511593248, 7);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511761722, 14);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511506848, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511420448, 14);



INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511679648, 2);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511593248, 7);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511761722, 14);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511506848, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511420448, 14);




INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511679648, 2);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511593248, 7);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511761722, 14);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511506848, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511420448, 14);



INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511679648, 2);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511593248, 7);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511761722, 14);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511506848, 10);

INSERT INTO elm08022017.emotion_date
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511420448, 14);




INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511766049, 7);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511679648, 14);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511593248, 10);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511506848, 10);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511420448, 14);





INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('5d7fae93-96fd-4c4249-90969d-4073925ae1b6', 1511679648, 2);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('5d7fae93-96fd-4c4249-90969d-4073925ae1b6', 1511593248, 7);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('5d7fae93-96fd-4c4249-90969d-4073925ae1b6', 1511761722, 14);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('5d7fae93-96fd-4c4249-90969d-4073925ae1b6', 1511506848, 10);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('5d7fae93-96fd-4c4249-90969d-4073925ae1b6', 1511420448, 14);





INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511679648, 2);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511593248, 7);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511761722, 14);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511506848, 10);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511420448, 14);



INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511679648, 2);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511593248, 7);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511761722, 14);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511506848, 10);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511420448, 14);



INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511679648, 2);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511593248, 7);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511761722, 14);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511506848, 10);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511420448, 14);



INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511679648, 2);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511593248, 7);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511761722, 14);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511506848, 10);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511420448, 14);


INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511679648, 2);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511593248, 7);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511761722, 14);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511506848, 10);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511420448, 14);


INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511679648, 2);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511593248, 7);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511761722, 14);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511506848, 10);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511420448, 14);


INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511679648, 2);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511593248, 7);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511761722, 14);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511506848, 10);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511420448, 14);



INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511679648, 2);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511593248, 7);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511761722, 14);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511506848, 10);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511420448, 14);


INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511679648, 2);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511593248, 7);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511761722, 14);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511506848, 10);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511420448, 14);


INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511679648, 2);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511593248, 7);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511761722, 14);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511506848, 10);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511420448, 14);


INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511679648, 2);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511593248, 7);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511761722, 14);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511506848, 10);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511420448, 14);



INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511679648, 2);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511593248, 7);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511761722, 14);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511506848, 10);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511420448, 14);



INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511679648, 2);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511593248, 7);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511761722, 14);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511506848, 10);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511420448, 14);



INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511679648, 2);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511593248, 7);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511761722, 14);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511506848, 10);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511420448, 14);




INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511679648, 2);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511593248, 7);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511761722, 14);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511506848, 10);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511420448, 14);



INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511679648, 2);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511593248, 7);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511761722, 14);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511506848, 10);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511420448, 14);


INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511679648, 2);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511593248, 7);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511761722, 14);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511506848, 10);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511420448, 14);


INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511679648, 2);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511593248, 7);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511761722, 14);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511506848, 10);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511420448, 14);


INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511679648, 2);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511593248, 7);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511761722, 14);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511506848, 10);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511420448, 14);



INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511679648, 2);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511593248, 7);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511761722, 14);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511506848, 10);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511420448, 14);



INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511679648, 2);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511593248, 7);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511761722, 14);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511506848, 10);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511420448, 14);



INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511679648, 2);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511593248, 7);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511761722, 14);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511506848, 10);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511420448, 14);



INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511679648, 2);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511593248, 7);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511761722, 14);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511506848, 10);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511420448, 14);



INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511679648, 2);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511593248, 7);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511761722, 14);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511506848, 10);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511420448, 14);


INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511679648, 2);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511593248, 7);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511761722, 14);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511506848, 10);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511420448, 14);


INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2e', 1511679648, 2);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2e', 1511593248, 7);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2e', 1511761722, 14);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2e', 1511506848, 10);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2e', 1511420448, 14);


INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511679648, 2);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511593248, 7);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511761722, 14);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511506848, 10);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511420448, 14);



INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511679648, 2);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511593248, 7);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511761722, 14);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511506848, 10);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511420448, 14);


INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511679648, 2);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511593248, 7);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511761722, 14);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511506848, 10);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511420448, 14);



INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511679648, 2);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511593248, 7);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511761722, 14);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511506848, 10);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511420448, 14);



INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511679648, 2);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511593248, 7);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511761722, 14);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511506848, 10);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511420448, 14);


INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511679648, 2);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511593248, 7);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511761722, 14);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511506848, 10);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511420448, 14);



INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511679648, 2);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511593248, 7);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511761722, 14);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511506848, 10);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511420448, 14);


INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511679648, 2);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511593248, 7);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511761722, 14);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511506848, 10);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511420448, 14);


INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511679648, 2);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511593248, 7);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511761722, 14);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511506848, 10);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511420448, 14);



INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511679648, 2);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511593248, 7);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511761722, 14);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511506848, 10);

INSERT INTO elm08022017.stress_date
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511420448, 14);




INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511761722, 5);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511766049, 7);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511679648, 14);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511593248, 10);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511420448, 14);



INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('63026db6-cf0f-4fb2-aefd-f297e451a346', 1511761722, 5);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('63026db6-cf0f-4fb2-aefd-f297e451a346', 1511766049, 7);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('63026db6-cf0f-4fb2-aefd-f297e451a346', 1511679648, 14);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('63026db6-cf0f-4fb2-aefd-f297e451a346', 1511593248, 10);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('63026db6-cf0f-4fb2-aefd-f297e451a346', 1511420448, 14);




INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511761722, 5);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511766049, 7);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511679648, 14);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511593248, 10);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511420448, 14);




INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511761722, 5);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511766049, 7);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511679648, 14);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511593248, 10);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511420448, 14);



INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511761722, 5);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511766049, 7);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511679648, 14);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511593248, 10);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511420448, 14);





INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511761722, 5);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511766049, 7);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511679648, 14);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511593248, 10);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511420448, 14);





INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511761722, 5);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511766049, 7);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511679648, 14);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511593248, 10);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511420448, 14);





INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511761722, 5);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511766049, 7);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511679648, 14);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511593248, 10);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511420448, 14);






INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511761722, 5);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511766049, 7);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511679648, 14);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511593248, 10);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511420448, 14);





INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511761722, 5);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511766049, 7);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511679648, 14);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511593248, 10);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511420448, 14);




INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511761722, 5);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511766049, 7);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511679648, 14);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511593248, 10);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511420448, 14);





INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511761722, 5);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511766049, 7);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511679648, 14);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511593248, 10);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511420448, 14);





INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511761722, 5);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511766049, 7);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511679648, 14);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511593248, 10);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511420448, 14);




INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511761722, 5);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511766049, 7);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511679648, 14);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511593248, 10);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511420448, 14);




INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511761722, 5);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511766049, 7);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511679648, 14);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511593248, 10);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511420448, 14);





INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511761722, 5);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511766049, 7);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511679648, 14);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511593248, 10);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511420448, 14);




INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511761722, 5);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511766049, 7);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511679648, 14);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511593248, 10);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511420448, 14);




INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511761722, 5);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511766049, 7);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511679648, 14);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511593248, 10);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511420448, 14);



INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511761722, 5);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511766049, 7);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511679648, 14);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511593248, 10);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511420448, 14);





INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511761722, 5);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511766049, 7);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511679648, 14);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511593248, 10);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511420448, 14);




INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511761722, 5);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511766049, 7);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511679648, 14);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511593248, 10);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511420448, 14);




INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511761722, 5);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511766049, 7);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511679648, 14);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511593248, 10);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511420448, 14);



INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511761722, 5);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511766049, 7);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511679648, 14);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511593248, 10);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511420448, 14);





INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511761722, 5);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511766049, 7);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511679648, 14);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511593248, 10);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511420448, 14);




INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511761722, 5);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511766049, 7);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511679648, 14);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511593248, 10);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511420448, 14);





INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511761722, 5);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511766049, 7);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511679648, 14);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511593248, 10);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511420448, 14);




INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511761722, 5);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511766049, 7);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511679648, 14);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511593248, 10);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511420448, 14);





INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2e', 1511761722, 5);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2e', 1511766049, 7);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2e', 1511679648, 14);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2eb', 1511593248, 10);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2e', 1511420448, 14);




INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511761722, 5);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511766049, 7);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511679648, 14);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511593248, 10);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511420448, 14);



INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511761722, 5);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511766049, 7);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511679648, 14);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511593248, 10);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511420448, 14);




INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511761722, 5);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511766049, 7);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511679648, 14);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511593248, 10);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511420448, 14);



INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511761722, 5);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511766049, 7);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511679648, 14);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511593248, 10);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511420448, 14);




INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511761722, 5);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511766049, 7);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511679648, 14);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511593248, 10);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511420448, 14);




INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511761722, 5);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511766049, 7);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511679648, 14);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511593248, 10);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511420448, 14);




INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511761722, 5);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511766049, 7);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511679648, 14);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511593248, 10);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511420448, 14);




INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511761722, 5);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511766049, 7);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511679648, 14);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511593248, 10);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511420448, 14);




INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511761722, 5);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511766049, 7);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511679648, 14);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511593248, 10);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511420448, 14);





INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511761722, 5);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511766049, 7);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511679648, 14);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511593248, 10);

INSERT INTO elm08022017.emotion_hour
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511420448, 14);





INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511761722, 5);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511766049, 7);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511679648, 14);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511593248, 10);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511420448, 14);



INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('63026db6-cf0f-4fb2-aefd-f297e451a346', 1511761722, 5);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('63026db6-cf0f-4fb2-aefd-f297e451a346', 1511766049, 7);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('63026db6-cf0f-4fb2-aefd-f297e451a346', 1511679648, 14);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('63026db6-cf0f-4fb2-aefd-f297e451a346', 1511593248, 10);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('63026db6-cf0f-4fb2-aefd-f297e451a346', 1511420448, 14);



INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511761722, 5);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511766049, 7);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511679648, 14);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511593248, 10);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511420448, 14);




INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511761722, 5);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511766049, 7);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511679648, 14);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511593248, 10);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511420448, 14);





INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511761722, 5);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511766049, 7);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511679648, 14);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511593248, 10);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511420448, 14);



INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511761722, 5);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511766049, 7);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511679648, 14);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511593248, 10);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511420448, 14);




INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511761722, 5);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511766049, 7);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511679648, 14);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511593248, 10);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511420448, 14);





INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511761722, 5);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511766049, 7);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511679648, 14);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511593248, 10);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511420448, 14);




INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511761722, 5);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511766049, 7);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511679648, 14);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511593248, 10);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511420448, 14);




INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511761722, 5);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511766049, 7);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511679648, 14);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511593248, 10);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511420448, 14);




INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511761722, 5);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511766049, 7);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511679648, 14);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511593248, 10);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511420448, 14);



INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511761722, 5);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511766049, 7);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511679648, 14);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511593248, 10);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511420448, 14);




INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511761722, 5);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511766049, 7);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511679648, 14);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511593248, 10);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511420448, 14);



INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511761722, 5);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511766049, 7);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511679648, 14);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511593248, 10);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511420448, 14);




INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511761722, 5);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511766049, 7);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511679648, 14);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511593248, 10);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511420448, 14);



INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511761722, 5);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511766049, 7);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511679648, 14);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511593248, 10);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511420448, 14);




INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511761722, 5);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511766049, 7);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511679648, 14);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511593248, 10);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511420448, 14);




INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511761722, 5);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511766049, 7);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511679648, 14);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511593248, 10);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511420448, 14);




INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511761722, 5);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511766049, 7);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511679648, 14);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511593248, 10);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511420448, 14);




INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511761722, 5);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511766049, 7);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511679648, 14);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511593248, 10);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511420448, 14);




INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511761722, 5);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511766049, 7);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511679648, 14);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511593248, 10);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511420448, 14);



INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511761722, 5);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511766049, 7);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511679648, 14);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511593248, 10);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511420448, 14);



INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511761722, 5);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511766049, 7);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511679648, 14);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511593248, 10);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511420448, 14);




INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511761722, 5);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511766049, 7);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511679648, 14);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511593248, 10);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511420448, 14);




INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511761722, 5);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511766049, 7);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511679648, 14);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511593248, 10);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511420448, 14);



INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511761722, 5);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511766049, 7);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511679648, 14);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511593248, 10);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511420448, 14);




INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511761722, 5);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511766049, 7);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511679648, 14);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511593248, 10);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511420448, 14);




INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2e', 1511761722, 5);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2e', 1511766049, 7);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2e', 1511679648, 14);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2e', 1511593248, 10);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2e', 1511420448, 14);




INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511761722, 5);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511766049, 7);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511679648, 14);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511593248, 10);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511420448, 14);




INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511761722, 5);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511766049, 7);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511679648, 14);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511593248, 10);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511420448, 14);



INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511761722, 5);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511766049, 7);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511679648, 14);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511593248, 10);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511420448, 14);





INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511761722, 5);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511766049, 7);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511679648, 14);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511593248, 10);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511420448, 14);



INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511761722, 5);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511766049, 7);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511679648, 14);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511593248, 10);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511420448, 14);



INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511761722, 5);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511766049, 7);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511679648, 14);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511593248, 10);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511420448, 14);



INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511761722, 5);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511766049, 7);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511679648, 14);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511593248, 10);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511420448, 14);




INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511761722, 5);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511766049, 7);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511679648, 14);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511593248, 10);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511420448, 14);




INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511761722, 5);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511766049, 7);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511679648, 14);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511593248, 10);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511420448, 14);




INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511761722, 5);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511766049, 7);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511679648, 14);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511593248, 10);

INSERT INTO elm08022017.stress_hour
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511420448, 14);



INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511766049, 7);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511679648, 14);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511593248, 10);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511420448, 14);



INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('63026db6-cf0f-4fb2-aefd-f297e451a346', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('63026db6-cf0f-4fb2-aefd-f297e451a346', 1511766049, 7);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('63026db6-cf0f-4fb2-aefd-f297e451a346', 1511679648, 14);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('63026db6-cf0f-4fb2-aefd-f297e451a346', 1511593248, 10);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('63026db6-cf0f-4fb2-aefd-f297e451a346', 1511420448, 14);



INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511766049, 7);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511679648, 14);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511593248, 10);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511420448, 14);




INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511766049, 7);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511679648, 14);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511593248, 10);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511420448, 14);





INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511766049, 7);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511679648, 14);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511593248, 10);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511420448, 14);



INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511766049, 7);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511679648, 14);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511593248, 10);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511420448, 14);




INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511766049, 7);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511679648, 14);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511593248, 10);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511420448, 14);





INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511766049, 7);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511679648, 14);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511593248, 10);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511420448, 14);




INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511766049, 7);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511679648, 14);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511593248, 10);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511420448, 14);




INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511766049, 7);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511679648, 14);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511593248, 10);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511420448, 14);




INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511766049, 7);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511679648, 14);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511593248, 10);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511420448, 14);



INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511766049, 7);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511679648, 14);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511593248, 10);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511420448, 14);




INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511766049, 7);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511679648, 14);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511593248, 10);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511420448, 14);



INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511766049, 7);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511679648, 14);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511593248, 10);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511420448, 14);




INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511766049, 7);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511679648, 14);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511593248, 10);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511420448, 14);



INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511766049, 7);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511679648, 14);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511593248, 10);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511420448, 14);




INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511766049, 7);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511679648, 14);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511593248, 10);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511420448, 14);




INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511766049, 7);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511679648, 14);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511593248, 10);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511420448, 14);




INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511766049, 7);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511679648, 14);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511593248, 10);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511420448, 14);




INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511766049, 7);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511679648, 14);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511593248, 10);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511420448, 14);




INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511766049, 7);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511679648, 14);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511593248, 10);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511420448, 14);



INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511766049, 7);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511679648, 14);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511593248, 10);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511420448, 14);



INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511766049, 7);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511679648, 14);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511593248, 10);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511420448, 14);




INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511766049, 7);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511679648, 14);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511593248, 10);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511420448, 14);




INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511766049, 7);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511679648, 14);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511593248, 10);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511420448, 14);



INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511766049, 7);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511679648, 14);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511593248, 10);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511420448, 14);




INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511766049, 7);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511679648, 14);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511593248, 10);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511420448, 14);




INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2e', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2e', 1511766049, 7);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2e', 1511679648, 14);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2e', 1511593248, 10);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2e', 1511420448, 14);




INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511766049, 7);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511679648, 14);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511593248, 10);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511420448, 14);




INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511766049, 7);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511679648, 14);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511593248, 10);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511420448, 14);



INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511766049, 7);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511679648, 14);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511593248, 10);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511420448, 14);





INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511766049, 7);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511679648, 14);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511593248, 10);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511420448, 14);



INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511766049, 7);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511679648, 14);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511593248, 10);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511420448, 14);



INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511766049, 7);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511679648, 14);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511593248, 10);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511420448, 14);



INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511766049, 7);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511679648, 14);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511593248, 10);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511420448, 14);




INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511766049, 7);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511679648, 14);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511593248, 10);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511420448, 14);




INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511766049, 7);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511679648, 14);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511593248, 10);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511420448, 14);




INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511766049, 7);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511679648, 14);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511593248, 10);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511420448, 14);




INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511766049, 7);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511593248, 10);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511761722, 5);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('5d7fae93-96fd-4c4249-90969d-4073925ae1b6', 1511766049, 1);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('5d7fae93-96fd-4c4249-90969d-4073925ae1b6', 1511679648, 4);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('5d7fae93-96fd-4c4249-90969d-4073925ae1b6', 1511593248, 12);

INSERT INTO elm08022017.emotion_week
(uuid, ts, ratio)
VALUES('5d7fae93-96fd-4c4249-90969d-4073925ae1b6', 1511761722, 6);



INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511766049, 7);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511679648, 14);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511593248, 10);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511420448, 14);



INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('63026db6-cf0f-4fb2-aefd-f297e451a346', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('63026db6-cf0f-4fb2-aefd-f297e451a346', 1511766049, 7);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('63026db6-cf0f-4fb2-aefd-f297e451a346', 1511679648, 14);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('63026db6-cf0f-4fb2-aefd-f297e451a346', 1511593248, 10);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('63026db6-cf0f-4fb2-aefd-f297e451a346', 1511420448, 14);



INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511766049, 7);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511679648, 14);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511593248, 10);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511420448, 14);




INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511766049, 7);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511679648, 14);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511593248, 10);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511420448, 14);





INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511766049, 7);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511679648, 14);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511593248, 10);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511420448, 14);



INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511766049, 7);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511679648, 14);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511593248, 10);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511420448, 14);




INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511766049, 7);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511679648, 14);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511593248, 10);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511420448, 14);





INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511766049, 7);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511679648, 14);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511593248, 10);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511420448, 14);




INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511766049, 7);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511679648, 14);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511593248, 10);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511420448, 14);




INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511766049, 7);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511679648, 14);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511593248, 10);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511420448, 14);




INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511766049, 7);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511679648, 14);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511593248, 10);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511420448, 14);



INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511766049, 7);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511679648, 14);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511593248, 10);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511420448, 14);




INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511766049, 7);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511679648, 14);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511593248, 10);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511420448, 14);



INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511766049, 7);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511679648, 14);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511593248, 10);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511420448, 14);




INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511766049, 7);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511679648, 14);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511593248, 10);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511420448, 14);



INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511766049, 7);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511679648, 14);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511593248, 10);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511420448, 14);




INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511766049, 7);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511679648, 14);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511593248, 10);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511420448, 14);



INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511766049, 7);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511679648, 14);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511593248, 10);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511420448, 14);




INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511766049, 7);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511679648, 14);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511593248, 10);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511420448, 14);




INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511766049, 7);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511679648, 14);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511593248, 10);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511420448, 14);




INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511766049, 7);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511679648, 14);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511593248, 10);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511420448, 14);



INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511766049, 7);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511679648, 14);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511593248, 10);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511420448, 14);



INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511766049, 7);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511679648, 14);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511593248, 10);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511420448, 14);




INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511766049, 7);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511679648, 14);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511593248, 10);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511420448, 14);




INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511766049, 7);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511679648, 14);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511593248, 10);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511420448, 14);



INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511766049, 7);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511679648, 14);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511593248, 10);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511420448, 14);




INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511766049, 7);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511679648, 14);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511593248, 10);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511420448, 14);




INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2e', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2e', 1511766049, 7);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2e', 1511679648, 14);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2e', 1511593248, 10);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2e', 1511420448, 14);




INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511766049, 7);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511679648, 14);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511593248, 10);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511420448, 14);




INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511766049, 7);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511679648, 14);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511593248, 10);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511420448, 14);



INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511766049, 7);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511679648, 14);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511593248, 10);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511420448, 14);





INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511766049, 7);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511679648, 14);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511593248, 10);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511420448, 14);



INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511766049, 7);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511679648, 14);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511593248, 10);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511420448, 14);



INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511766049, 7);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511679648, 14);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511593248, 10);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511420448, 14);



INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511766049, 7);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511679648, 14);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511593248, 10);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511420448, 14);




INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511766049, 7);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511679648, 14);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511593248, 10);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511420448, 14);




INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511766049, 7);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511679648, 14);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511593248, 10);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511420448, 14);



INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511766049, 7);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511679648, 14);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511593248, 10);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511420448, 14);



INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511766049, 7);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511593248, 10);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511761722, 5);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('5d7fae93-96fd-4c4249-90969d-4073925ae1b6', 1511766049, 1);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('5d7fae93-96fd-4c4249-90969d-4073925ae1b6', 1511679648, 4);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('5d7fae93-96fd-4c4249-90969d-4073925ae1b6', 1511593248, 12);

INSERT INTO elm08022017.stress_week
(uuid, ts, ratio)
VALUES('5d7fae93-96fd-4c4249-90969d-4073925ae1b6', 1511761722, 6);




INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511766049, 7);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511679648, 14);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511593248, 10);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511420448, 14);



INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('63026db6-cf0f-4fb2-aefd-f297e451a346', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('63026db6-cf0f-4fb2-aefd-f297e451a346', 1511766049, 7);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('63026db6-cf0f-4fb2-aefd-f297e451a346', 1511679648, 14);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('63026db6-cf0f-4fb2-aefd-f297e451a346', 1511593248, 10);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('63026db6-cf0f-4fb2-aefd-f297e451a346', 1511420448, 14);



INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511766049, 7);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511679648, 14);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511593248, 10);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511420448, 14);




INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511766049, 7);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511679648, 14);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511593248, 10);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511420448, 14);





INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511766049, 7);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511679648, 14);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511593248, 10);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511420448, 14);



INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511766049, 7);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511679648, 14);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511593248, 10);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511420448, 14);




INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511766049, 7);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511679648, 14);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511593248, 10);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511420448, 14);





INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511766049, 7);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511679648, 14);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511593248, 10);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511420448, 14);




INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511766049, 7);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511679648, 14);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511593248, 10);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511420448, 14);




INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511766049, 7);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511679648, 14);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511593248, 10);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511420448, 14);




INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511766049, 7);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511679648, 14);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511593248, 10);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511420448, 14);



INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511766049, 7);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511679648, 14);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511593248, 10);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511420448, 14);




INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511766049, 7);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511679648, 14);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511593248, 10);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511420448, 14);



INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511766049, 7);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511679648, 14);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511593248, 10);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511420448, 14);




INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511766049, 7);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511679648, 14);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511593248, 10);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511420448, 14);



INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511766049, 7);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511679648, 14);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511593248, 10);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511420448, 14);



INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511766049, 7);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511679648, 14);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511593248, 10);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511420448, 14);




INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511766049, 7);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511679648, 14);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511593248, 10);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511420448, 14);




INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511766049, 7);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511679648, 14);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511593248, 10);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511420448, 14);




INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511766049, 7);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511679648, 14);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511593248, 10);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511420448, 14);




INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511766049, 7);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511679648, 14);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511593248, 10);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511420448, 14);



INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511766049, 7);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511679648, 14);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511593248, 10);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511420448, 14);



INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511766049, 7);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511679648, 14);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511593248, 10);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511420448, 14);




INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511766049, 7);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511679648, 14);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511593248, 10);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511420448, 14);



INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511766049, 7);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511679648, 14);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511593248, 10);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511420448, 14);



INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511766049, 7);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511679648, 14);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511593248, 10);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511420448, 14);




INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511766049, 7);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511679648, 14);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511593248, 10);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511420448, 14);




INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2e', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2e', 1511766049, 7);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2e', 1511679648, 14);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2e', 1511593248, 10);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2e', 1511420448, 14);


INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511766049, 7);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511679648, 14);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511593248, 10);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511420448, 14);



INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511766049, 7);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511679648, 14);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511593248, 10);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511420448, 14);



INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511766049, 7);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511679648, 14);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511593248, 10);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511420448, 14);



INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511766049, 7);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511679648, 14);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511593248, 10);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511420448, 14);



INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511766049, 7);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511679648, 14);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511593248, 10);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511420448, 14);



INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511766049, 7);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511679648, 14);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511593248, 10);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511420448, 14);



INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511766049, 7);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511679648, 14);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511593248, 10);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511420448, 14);



INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511766049, 7);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511679648, 14);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511593248, 10);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511420448, 14);




INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511766049, 7);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511679648, 14);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511593248, 10);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511420448, 14);




INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511766049, 7);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511679648, 14);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511593248, 10);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511420448, 14);



INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511766049, 7);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511593248, 10);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511761722, 5);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('5d7fae93-96fd-4c4249-90969d-4073925ae1b6', 1511766049, 1);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('5d7fae93-96fd-4c4249-90969d-4073925ae1b6', 1511679648, 4);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('5d7fae93-96fd-4c4249-90969d-4073925ae1b6', 1511593248, 12);

INSERT INTO elm08022017.emotion_month
(uuid, ts, ratio)
VALUES('5d7fae93-96fd-4c4249-90969d-4073925ae1b6', 1511761722, 6);





INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511766049, 7);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511679648, 14);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511593248, 10);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('3e1ad934-04a9-4cb9-87f1-b10cf6ce9a76', 1511420448, 14);



INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('63026db6-cf0f-4fb2-aefd-f297e451a346', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('63026db6-cf0f-4fb2-aefd-f297e451a346', 1511766049, 7);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('63026db6-cf0f-4fb2-aefd-f297e451a346', 1511679648, 14);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('63026db6-cf0f-4fb2-aefd-f297e451a346', 1511593248, 10);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('63026db6-cf0f-4fb2-aefd-f297e451a346', 1511420448, 14);



INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511766049, 7);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511679648, 14);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511593248, 10);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('1b12dec0-ab84-48d6-95f7-92bf119770bd', 1511420448, 14);




INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511766049, 7);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511679648, 14);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511593248, 10);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('dc4888ce-5995-432b-ac55-671107eff9eb', 1511420448, 14);





INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511766049, 7);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511679648, 14);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511593248, 10);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('a9999cc6-7dab-4176-b344-770e917f2c32', 1511420448, 14);



INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511766049, 7);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511679648, 14);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511593248, 10);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('ce11418b-b068-455a-8edd-c6d656500519', 1511420448, 14);




INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511766049, 7);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511679648, 14);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511593248, 10);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('0cfba685-9ba7-4013-81ca-e3d8ab3a1b39', 1511420448, 14);





INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511766049, 7);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511679648, 14);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511593248, 10);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('aebe58c1-9697-453d-bdeb-8a4ae44b258f', 1511420448, 14);




INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511766049, 7);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511679648, 14);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511593248, 10);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('7ae8833d-dccd-42f2-b410-b91312c3b336', 1511420448, 14);




INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511766049, 7);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511679648, 14);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511593248, 10);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('2e52bb6a-774d-4064-8dbf-4c8e0ca5fe4d', 1511420448, 14);




INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511766049, 7);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511679648, 14);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511593248, 10);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('9f7ad649-ae9c-4dca-86fa-821c447625eb', 1511420448, 14);



INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511766049, 7);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511679648, 14);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511593248, 10);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('562da6df-c403-49df-83d7-a564513c178f', 1511420448, 14);




INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511766049, 7);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511679648, 14);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511593248, 10);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511420448, 14);



INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511766049, 7);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511679648, 14);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511593248, 10);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('508650c7-8646-426a-a0ea-29143780f0aa', 1511420448, 14);




INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511766049, 7);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511679648, 14);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511593248, 10);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511420448, 14);



INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511766049, 7);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511679648, 14);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511593248, 10);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('ca3ab781-346c-4dae-a330-4eccd5b8fde7', 1511420448, 14);




INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511766049, 7);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511679648, 14);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511593248, 10);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('24412b05-a20a-413f-9ab4-bcef1ba96b78', 1511420448, 14);




INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511766049, 7);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511679648, 14);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511593248, 10);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('28d0691d-d56c-4c6d-8d8c-88be73273f10', 1511420448, 14);




INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511766049, 7);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511679648, 14);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511593248, 10);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('66ce63c3-7e6a-41bb-bd29-1a620d829ea4', 1511420448, 14);




INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511766049, 7);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511679648, 14);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511593248, 10);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('ca2ad182-4616-417b-84cb-1c492cc39dc3', 1511420448, 14);




INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511766049, 7);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511679648, 14);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511593248, 10);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('e7b6946e-74a4-4cc0-ad27-f48a7fb165ae', 1511420448, 14);



INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511766049, 7);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511679648, 14);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511593248, 10);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('a81f9087-286c-4130-98b8-51d3769cd951', 1511420448, 14);



INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511766049, 7);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511679648, 14);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511593248, 10);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('e2a2774f-2f72-493e-89ea-f1d880ec06a4', 1511420448, 14);




INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511766049, 7);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511679648, 14);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511593248, 10);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('60396210-e3be-4dd0-ab17-093d7ab417d1', 1511420448, 14);




INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511766049, 7);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511679648, 14);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511593248, 10);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('a8e2a3c2-c299-4f71-833b-c83dbbb53520', 1511420448, 14);



INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511766049, 7);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511679648, 14);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511593248, 10);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('b217cb97-826a-46dc-9881-76f6307e332e', 1511420448, 14);




INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511766049, 7);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511679648, 14);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511593248, 10);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('bf528a18-e059-456d-9371-9e8131a01cbb', 1511420448, 14);



INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2e', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2e', 1511766049, 7);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2e', 1511679648, 14);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2e', 1511593248, 10);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('89b11e6d-d0b9-49e8-a538-d8e154ddea2e', 1511420448, 14);




INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511766049, 7);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511679648, 14);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511593248, 10);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('e99dd5e8-7bea-42a2-8404-bd26e50a9eed', 1511420448, 14);




INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511766049, 7);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511679648, 14);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511593248, 10);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('4232efe7-5241-4048-a47f-78c7759a0a81', 1511420448, 14);



INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511766049, 7);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511679648, 14);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511593248, 10);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('f6dd92d2-4a03-4fe7-a209-67a29a59108d', 1511420448, 14);





INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511766049, 7);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511679648, 14);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511593248, 10);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('336781f8-09da-49de-b6de-70b598920be2', 1511420448, 14);



INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511766049, 7);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511679648, 14);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511593248, 10);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('65758d67-4fca-42d9-af49-412b04e7cc88', 1511420448, 14);



INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511766049, 7);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511679648, 14);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511593248, 10);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('96dc1fd4-e801-43aa-8699-2314e7059e82', 1511420448, 14);



INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511766049, 7);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511679648, 14);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511593248, 10);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('b5a7079c-3107-40fa-ac6e-ef55e86408c3', 1511420448, 14);




INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511766049, 7);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511679648, 14);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511593248, 10);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('638ddcdd-6c13-4c8d-8a6c-5c814524c627', 1511420448, 14);




INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511766049, 7);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511679648, 14);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511593248, 10);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('5849d6bb-512e-49f3-bc96-e943d53db9b9', 1511420448, 14);




INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511766049, 7);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511679648, 14);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511593248, 10);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('5d0a5a85-b970-440c-ac88-27323a4d6b6e', 1511420448, 14);




INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511766049, 7);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511593248, 10);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('3e947738-8cc4-4449-acf9-4dfafa749e36', 1511761722, 5);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('5d7fae93-96fd-4c4249-90969d-4073925ae1b6', 1511766049, 1);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('5d7fae93-96fd-4c4249-90969d-4073925ae1b6', 1511679648, 4);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('5d7fae93-96fd-4c4249-90969d-4073925ae1b6', 1511593248, 12);

INSERT INTO elm08022017.stress_month
(uuid, ts, ratio)
VALUES('5d7fae93-96fd-4c4249-90969d-4073925ae1b6', 1511761722, 6);






